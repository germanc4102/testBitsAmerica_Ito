package com.example.demo.dto;

public class Rol {
	int ID;
	String NOMBRE;
	String DESCRIPCION;
	int activo;
	int eliminado;
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getNOMBRE() {
		return NOMBRE;
	}
	public void setNOMBRE(String nOMBRE) {
		NOMBRE = nOMBRE;
	}
	public String getDESCRIPCION() {
		return DESCRIPCION;
	}
	public void setDESCRIPCION(String dESCRIPCION) {
		DESCRIPCION = dESCRIPCION;
	}
	public int getActivo() {
		return activo;
	}
	public void setActivo(int activo) {
		this.activo = activo;
	}
	public int getEliminado() {
		return eliminado;
	}
	public void setEliminado(int eliminado) {
		this.eliminado = eliminado;
	}
	public Rol(int iD, String nOMBRE, String dESCRIPCION, int activo, int eliminado) {
		super();
		ID = iD;
		NOMBRE = nOMBRE;
		DESCRIPCION = dESCRIPCION;
		this.activo = activo;
		this.eliminado = eliminado;
	}
	@Override
	public String toString() {
		return "Rol [ID=" + ID + ", NOMBRE=" + NOMBRE + ", DESCRIPCION=" + DESCRIPCION + ", activo=" + activo
				+ ", eliminado=" + eliminado + "]";
	}
}
