package com.example.demo.api;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Rol;

@RestController

public class RolApi{
	@RequestMapping(value="/product", method=RequestMethod.GET)
	public Rol getById(){
        return new Rol(234, "Test", "Test2", 1, 2);
    }
}
