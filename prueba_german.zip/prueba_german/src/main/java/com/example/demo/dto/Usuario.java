package com.example.demo.dto;

public class Usuario {
	int ID;
	String USUARIO;
	String CLAVE;
	String IDENTIFICACION;
	String APELLIDOS;
	String NOMBRES;
}
